// Object Literals
const motelCustomer = {
        firsName: 'Hilton',
        lastName: 'Danny',
        birthDate: {day: '01', 
            month: '01', 
            year: '1976'
        }, 
        gender: 'Male',
        roomPrefernce: ['Non-smoking', 'King bed', 'Ocean view'],
        PaymentMethod: 'Credit Card',
        mailingAddress: {
            street: '123 Main Street',
            city: 'St. Johns',
            province: 'NL',
            postal: 'A1F6J7',
            country: 'CANADA'
        },
        phoneNumber: '123-456-7890',
        emergencyContactName: 'John Doe',
        emergencyContactNumber: '321-456-7890',
        emailAddress: '2JqzK@gmail.com',
        identification: ['Drivers license', 'passport', 'National ID'],
        checkInDate: '2023-11-20',
        checkOutDate: {
            year: '2023',
            month: '11',
            day: '25',
        },
        getAge: function(){
            const today = new Date();
            return today.getFullYear() - this.birthDate.year;
        }
        }

        function calculateDurationOfStay(checkInDate, checkOutDate) {
            const oneDay = 24 * 60 * 60 * 1000; // Number of milliseconds in a day
        
            const checkin = new Date(checkInDate);
            const checkout = new Date(checkOutDate);
        
            // Calculate the difference between check-out and check-in dates
            const diffDays = Math.round(Math.abs((checkout - checkin) / oneDay));
        
            return diffDays; // Return the duration of stay in days
            }
        {
        
    };

    // let peeps;
    // peeps = motelCustomer.getAge();
    // console.log(peeps);

    // const duration = calculateDurationOfStay('2023-11-20', '2023-11-25');
    // console.log(duration); 

