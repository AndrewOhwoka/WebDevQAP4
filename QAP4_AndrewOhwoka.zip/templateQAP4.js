const firstName = 'Hilton';
const lastName = 'Danny';
const age = 47;
const gender = 'Male';
const roomPrefernce = ['Non-smoking', 'King bed', 'Ocean view'];
const paymentMethod = 'Credit Card';
const street = '123 Main Street';
const city = 'St. Johns';
const province = 'NL';
const postal = 'A1F6J7';
const country = 'CANADA';
const phoneNumber = '123-456-7890';
const emergencyContactName = 'John Doe';
const emergencyContactNumber = '321-456-7890';
const emailAddress = '2JqzK@gmail.com';
const identification = ['Drivers license', 'passport', 'National ID'];
const checkInDate = '2023-11-20';
const checkOutDate = '2023-11-25';
let aString;
let html;


html = `
  <ul>
    <li>First: ${firstName} </li>
    <li>Last: ${lastName} </li>
    <li>Age: ${age} </li>
    <li>Gender: ${gender} </li>
    <li>Room Preference: ${roomPrefernce } </li>
    <li>Payment Method: ${paymentMethod} </li>
    <li>Street: ${street} </li>
    <li>City: ${city} </li>
    <li>Province: ${province} </li>
    <li>Postal: ${postal} </li>
    <li>Country: ${country} </li>
    <li>Phone Number: ${phoneNumber} </li>
    <li>Emergency Contact Name: ${emergencyContactName} </li>
    <li>Emergency Contact Number: ${emergencyContactNumber} </li>
    <li>Email Address: ${emailAddress} </li>
    <li>Identification: ${identification} </li>
    <li>Check In Date: ${checkInDate} </li>
    <li>Check Out Date: ${checkOutDate} </li>
  </ul>
`;

console.log(html);
document.body.innerHTML = html;

